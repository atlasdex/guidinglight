import { TransactionInstruction } from "@solana/web3.js";
export declare function ixFromRust(data: any): TransactionInstruction;
