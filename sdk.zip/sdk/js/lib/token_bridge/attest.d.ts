import { Connection, Transaction } from "@solana/web3.js";
import { ethers } from "ethers";
import { MsgExecuteContract } from "@terra-money/terra.js";
export declare function attestFromEth(tokenBridgeAddress: string, signer: ethers.Signer, tokenAddress: string): Promise<ethers.ContractReceipt>;
export declare function attestFromTerra(tokenBridgeAddress: string, walletAddress: string, asset: string): Promise<MsgExecuteContract>;
export declare function attestFromSolana(connection: Connection, bridgeAddress: string, tokenBridgeAddress: string, payerAddress: string, mintAddress: string): Promise<Transaction>;
