import { ChainId } from "./consts";
export declare const isHexNativeTerra: (h: string) => boolean;
export declare const nativeTerraHexToDenom: (h: string) => string;
export declare const uint8ArrayToHex: (a: Uint8Array) => string;
export declare const hexToUint8Array: (h: string) => Uint8Array;
export declare const hexToNativeString: (h: string | undefined, c: ChainId) => string | undefined;
