export default function shareMintAddress(program_id: string, pool: string): Promise<Uint8Array>;
