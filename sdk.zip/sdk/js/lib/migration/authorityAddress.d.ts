export default function authorityAddress(program_id: string): Promise<Uint8Array>;
