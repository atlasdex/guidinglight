export default function parsePool(data: Uint8Array): Promise<any>;
