export declare type ChainId = 1 | 2 | 3 | 4;
export declare const CHAIN_ID_SOLANA: ChainId;
export declare const CHAIN_ID_ETH: ChainId;
export declare const CHAIN_ID_TERRA: ChainId;
export declare const CHAIN_ID_BSC: ChainId;
export declare const WSOL_ADDRESS = "So11111111111111111111111111111111111111112";
export declare const WSOL_DECIMALS = 9;
export declare const MAX_VAA_DECIMALS = 8;
