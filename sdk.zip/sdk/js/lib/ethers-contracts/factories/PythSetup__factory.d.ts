import { Signer, ContractFactory, Overrides } from "ethers";
import { Provider, TransactionRequest } from "@ethersproject/providers";
import type { PythSetup, PythSetupInterface } from "../PythSetup";
export declare class PythSetup__factory extends ContractFactory {
    constructor(signer?: Signer);
    deploy(overrides?: Overrides & {
        from?: string | Promise<string>;
    }): Promise<PythSetup>;
    getDeployTransaction(overrides?: Overrides & {
        from?: string | Promise<string>;
    }): TransactionRequest;
    attach(address: string): PythSetup;
    connect(signer: Signer): PythSetup__factory;
    static readonly bytecode = "0x608060405234801561001057600080fd5b50610276806100206000396000f3fe608060405234801561001057600080fd5b506004361061002b5760003560e01c8063129acf8d14610030575b600080fd5b61004361003e3660046101c9565b610045565b005b60018054600080546001600160a01b0389166001600160a01b031990911617905561ffff868116620100000263ffffffff199092169089161717905560028390556003805461ffff191661ffff84161790556100a081600455565b6100a9876100b2565b50505050505050565b6100bb816100f2565b6040516001600160a01b038216907fbc7cd75a20ee27fd9adebab32041f755214dbc6bffa90cc0225b39da2e5c2d3b90600090a250565b803b61015a5760405162461bcd60e51b815260206004820152602d60248201527f455243313936373a206e657720696d706c656d656e746174696f6e206973206e60448201526c1bdd08184818dbdb9d1c9858dd609a1b606482015260840160405180910390fd5b7f360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc80546001600160a01b0319166001600160a01b0392909216919091179055565b80356001600160a01b03811681146101b257600080fd5b919050565b803561ffff811681146101b257600080fd5b600080600080600080600060e0888a0312156101e3578283fd5b6101ec8861019b565b96506101fa602089016101b7565b95506102086040890161019b565b9450610216606089016101b7565b93506080880135925061022b60a089016101b7565b915060c088013590509295989194975092955056fea2646970667358221220e50bedbd30e4c9436b686f843f7a21ff112e6956fb02106b90c04ef930af875164736f6c63430008040033";
    static readonly abi: ({
        anonymous: boolean;
        inputs: {
            indexed: boolean;
            internalType: string;
            name: string;
            type: string;
        }[];
        name: string;
        type: string;
        outputs?: undefined;
        stateMutability?: undefined;
    } | {
        inputs: {
            internalType: string;
            name: string;
            type: string;
        }[];
        name: string;
        outputs: never[];
        stateMutability: string;
        type: string;
        anonymous?: undefined;
    })[];
    static createInterface(): PythSetupInterface;
    static connect(address: string, signerOrProvider: Signer | Provider): PythSetup;
}
