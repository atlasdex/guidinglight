/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function post_message_ix(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number, k: number, l: number, m: number): number;
export function post_vaa_ix(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number): number;
export function update_guardian_set_ix(a: number, b: number, c: number, d: number, e: number, f: number): number;
export function set_fees_ix(a: number, b: number, c: number, d: number, e: number, f: number): number;
export function transfer_fees_ix(a: number, b: number, c: number, d: number, e: number, f: number): number;
export function upgrade_contract_ix(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number): number;
export function verify_signatures_ix(a: number, b: number, c: number, d: number, e: number, f: number, g: number, h: number, i: number, j: number): number;
export function guardian_set_address(a: number, b: number, c: number, d: number): void;
export function parse_guardian_set(a: number, b: number): number;
export function state_address(a: number, b: number, c: number): void;
export function parse_state(a: number, b: number): number;
export function fee_collector_address(a: number, b: number, c: number): void;
export function claim_address(a: number, b: number, c: number, d: number, e: number): void;
export function parse_posted_message(a: number, b: number): number;
export function parse_vaa(a: number, b: number): number;
export function __wbindgen_malloc(a: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number): number;
export function __wbindgen_add_to_stack_pointer(a: number): number;
export function __wbindgen_free(a: number, b: number): void;
