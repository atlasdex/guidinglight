export default function fromCustodyAddress(program_id: string, pool: string): Promise<Uint8Array>;
